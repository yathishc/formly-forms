import { Component } from '@angular/core';
import { FieldType } from '@ngx-formly/core';
import { CuiInputComponent, CuiSelectComponent} from "@cisco-ngx/cui-components";

@Component({
 selector: 'formly-dropdown',
 template: `              
         
    <cui-select [items]="to.options" label="{{to.label}}"  [formControl]="formControl" [formlyAttributes]="field" required="{{to.required}}" ></cui-select>
             
 `,
})
export class FormlyDropdown extends FieldType {}